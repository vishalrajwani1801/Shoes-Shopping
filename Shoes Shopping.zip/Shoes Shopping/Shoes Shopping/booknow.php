<?php
	require_once('connection.php');
	require_once('header.php');
	$id=$_GET['id'];
?>

<header class="section background-primary text-center">
 <?php
		$sql = "select * from products where p_id=".$id;
		$result = mysqli_query($connection,$sql);
		while($row = mysqli_fetch_array($result))
		{
		
		?>
            <h1 class="text-white margin-bottom-0 text-size-50 text-thin text-line-height-1"><?php echo $row['p_name'];?></h1>
			 <?php
					
					 
					   $i++;
					  }
					
					?>
        </header>
<div class="container" style="padding-top:50px;">
<div class="contact-content">
		 
       							<form action="booknow_ins.php" method="post">
							    	<input type="text" class="textbox" name="b_name" value=" Your Name" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Your Name';}">
							    	<input type="text" class="textbox" name="b_email" value="Your E-Mail" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Your E-Mail';}">
									<input type="text" class="textbox" name="b_mobno" value="Your Mobile No." onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Your Phone Number';}">
										<div class="clear"> </div>
								    <div>
									<input type="hidden" name="p_id" value="<?php echo $id; ?>" />
								    	<textarea value="Address:" name="b_address" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Your Message ';}">Your Address</textarea>
								    </div>	
								   <div class="submit"> 
								    	<input type="submit" value="Buy Now " />
					              </div>
								</form>
							</div>
							</div>



<?php
	require_once('footer.php');
?>