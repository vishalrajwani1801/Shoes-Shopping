<?php
	
	require_once('header.php');
?>


<header class="section background-primary text-center">
            <h1 class="text-white margin-bottom-0 text-size-50 text-thin text-line-height-1">Category</h1>
        </header>
	<div class="pad">
<br>

	<div class="container">
	<?php
					$sql = "SELECT * FROM `category`";
					$result = mysqli_query($connection,$sql);
					$i = 1;

					
				    	while($row = mysqli_fetch_array($result))
						{ 
						?>

	<div class="col-md-3">
<center><h3>
<a href="product-listing.php?id=<?php echo $row['cat_id']; ?>"><img style="width:300px;height:200px;" src="admin-panel/uploads/<?php echo $row['cat_img']; ?>" class="img-responsive img1" alt=""/></a>
</th><br>				
<p><br><h3 class="size" style="text-align:center;"><a href="product-listing.php?id=<?php echo $row['cat_id']; ?>"><?php echo $row['cat_name'];?></tr></table>
</a>
</h3>			
</p>

	</div>
	<?php
					
					 
					   $i++;
					  }
					
					?>
		<div class="clearfix"> </div>
		</div>
	</div>



<?php
	require_once('footer.php');
?>