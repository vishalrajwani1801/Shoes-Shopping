<?php
	
	require_once('header.php');
?>


<header class="section background-primary text-center">
            <h1 class="text-white margin-bottom-0 text-size-50 text-thin text-line-height-1">Accessories</h1>
        </header>
	<div class="pad">
	<div class="container">
	<?php
					$sql = "SELECT * FROM `category` where section = 'Accessories'";
					$result = mysqli_query($connection,$sql);
					$i = 1;

					
				    	while($row = mysqli_fetch_array($result))
						{ 
						?>
	<div class="col-md-3">
	<a href="product-listing.php?id=<?php echo $row['cat_id']; ?>"><img src="admin-panel/uploads/<?php echo $row['cat_img']; ?>" class="img-responsive img1" alt=""/></a>
				<h2 class="size" style="text-align:center;"><a href="product-listing.php?id=<?php echo $row['cat_id']; ?>"><?php echo $row['cat_name'];?></a></h2>
			
	</div>
	<?php
					
					 
					   $i++;
					  }
					
					?>
		<div class="clearfix"> </div>
		</div>
	</div>



<?php
	require_once('footer.php');
?>