<?php
	require_once('connection.php');
	require_once('header.php');
	$id=$_GET['id'];
?>



<header>
 <?php
		$sql = "select * from products where p_id=".$id;
		$result = mysqli_query($connection,$sql);
		while($row = mysqli_fetch_array($connection,$result))
		{
		
		?>
            <h1 class="text-white margin-bottom-0 text-size-50 text-thin text-line-height-1"><?php echo $row['p_name'];?></h1>
			 <?php
					
					 
					   $i++;
					  }
					
					?>
        </header>
	<div class="register">
	  <div class="container">
	  	<div class="about_box">
		<div class="col-md-3 col_4">
		<?php
		$sql = "select * from products where p_id=".$id;
		$result = mysqli_query($connection,$sql);
		while($row = mysqli_fetch_array($result))
		{
		
		?>
	  	   <img src="admin-panel/puploads/<?php echo $row['p_img'];?>" class="img-responsive" alt=""/>
		  
			<h2 class="size" style="text-align:center;"> <i><?php echo $row['p_name'];?><i></h2>
			
Price: <?php echo $row['price'];?></h2>	<br><br>	  
 <a href="booknow.php?id=<?php echo $row['p_id'];?>"><input type="button" value="Buy Now" /></a>
	  	  </div>
	  	  <div class="col-md-9 col_3"><p><h3><?php echo $row['p_desc'];?></h3></p>
			
	  	  </div>
		 
	  	  <?php
					
					 
					   $i++;
					  }
					
					?>
		  <div class="clearfix"> </div>
		</div>
		</div>
		</div>


<?php
	require_once('footer.php');
?>