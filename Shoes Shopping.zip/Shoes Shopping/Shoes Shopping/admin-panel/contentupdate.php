<?php
include('connection.php');
$id = $_POST['id'];

$welcome_title = $_POST['welcome_title'];
$welcome_text = addslashes($_POST['welcome_text']);
$banner_text = $_POST['banner_text'];
$ph_number = $_POST['ph_number'];
$email = $_POST['email'];
$address = $_POST['address'];
$vision_text = addslashes($_POST['vision_text']);
	
 $query = "UPDATE `contect` SET welcome_title = '$welcome_title', welcome_text = '$welcome_text', banner_text = '$banner_text',  ph_number = '$ph_number',  email = '$email',  address = '$address', vision_text = '$vision_text' WHERE id = ".$id;

		mysqli_query($connection,$query);
		header("location:content.php");

?>