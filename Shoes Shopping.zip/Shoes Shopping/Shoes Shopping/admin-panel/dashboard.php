<?php
session_start();
require_once('connection.php');
require_once('header.php');
?>
                    
                    
                    
                    
    <div class="center_content">  
    
    
    <?php
	//require_once('sidebar.php');
?>      
    
    <div class="right_content">            
        
    <h2>Categories Settings</h2> 
                    
                    
<table id="rounded-corner" summary="2019 Major IT Companies' Profit">
    <thead>
    	<tr>
        	<th scope="col" class="rounded">Sr. No.</th>
			 <th scope="col" class="rounded">Section</th>
            <th scope="col" class="rounded">Category Name</th>
			 <th scope="col" class="rounded">Category Image</th>
			 <th scope="col" class="rounded">View</th>
            <th scope="col" class="rounded">Edit</th>
            <th scope="col" class="rounded-q4">Delete</th>
        </tr>
    </thead>
        
    <tbody>
	<?php
					$sql = "SELECT * FROM `category`";
					$result = mysqli_query($connection,$sql);
					$i = 1;

					
				    	while($row = mysqli_fetch_array($result))
						{ 
						
						?>
    	<tr>
        	 <td><?php echo $i; ?></td>
			 <td><?php echo $row['section'];?> </td>
            <td><?php echo $row['cat_name'];?> </td>
			 <td><img src="uploads/<?php echo $row['cat_img'];?>" alt="" title="" border="0" height="50" width="50" /></td>
			  <td><a href="view-cat.php?id=<?php echo $row['cat_id'];?>"><img src="images/info.png" alt="" title="" border="0" /></a></td>
                        <td><a href="editcat.php?id=<?php echo $row['cat_id'];?>"><img src="images/user_edit.png" alt="" title="" border="0" /></a></td>
            <td><a href="category_delete.php?id=<?php echo $row['cat_id'];?>" class="ask"><img src="images/trash.png" alt="" title="" border="0" /></a></td>
        </tr>
         <?php
					 $i++;
					  }
					
					?>
                     
    	 
        
    	    
        
    </tbody>
</table>

	 <a href="addcat.php" class="bt_green"><span class="bt_green_lft"></span><strong>Add new item</strong><span class="bt_green_r"></span></a>
     
    
     
     
         
      
     
     </div><!-- end of right content-->
            
                    
  </div>   <!--end of center content -->               
                    
                    
    
    
    <div class="clear"></div>
    </div> <!--end of main content-->
	
 <?php
	require_once('footer.php');
?>      
    

</div>		
</body>
</html>