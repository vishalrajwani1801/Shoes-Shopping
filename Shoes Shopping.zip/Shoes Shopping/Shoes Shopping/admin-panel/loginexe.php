<?php
session_start();
require_once('connection.php');
$usernm = $_POST['usernm'];
$pass = $_POST['pass'];



    $query="SELECT * FROM `admin_tbl` WHERE `user_nm`='$usernm' and `pass`='$pass'";

    $res=mysqli_query($connection,$query);
    $checkUser=mysqli_num_rows($res);
	
	
    if($checkUser > 0){
         $_SESSION['LOGIN_STATUS']="True";
         
		
		 $con="SELECT * FROM `admin_tbl` WHERE `user_nm`='$usernm' and `pass`='$pass'";
	     $result = mysqli_query($connection,$con);
         if($row = mysqli_fetch_array($result))
		 {
			  $_SESSION['usernm']= $row['user_nm'];
		 }
		 
         echo 'correct';
		 header('location:content.php');
    }else{
         echo "Please Enter Correct user Details";
    }

?>