<?php
require_once('connection.php');

echo $cat_id = $_POST['cat_id'];
echo $p_name = $_POST['p_name'];
echo $p_desc = $_POST['p_desc'];
echo $price = $_POST['price'];

if(!empty($_FILES["prod_image"]["name"])){
		 $filename = time().$_FILES["prod_image"]["name"];
		 move_uploaded_file($_FILES["prod_image"]["tmp_name"],"puploads/".$filename);
		
	}

$query = "INSERT INTO `products` (`cat_id`, `p_name`, `p_desc`, `price`, `p_img`) VALUES ('$cat_id', '$p_name', '$p_desc', '$price', '$filename')";
mysqli_query($connection,$query);
header('location:product_listing.php');

?>
