<?php
session_start();
require_once('connection.php');
require_once('header.php');
?>
                    
                    
                    
                    
    <div class="center_content">  
    
    
    <?php
	//require_once('sidebar.php');
?>      
    
    <div class="right_content">            
        
    <h2>Add New Category</h2> 
                    
     
     
     
         <div class="form">
         <form action="catexe.php" method="post" class="niceform" enctype="multipart/form-data">
         
                <fieldset>
					<!-- <dl>
					 <dt><label for="email">Section:</label></dt>
					 <dd><input type="radio" name="section" value="Cloths" id="" />  &nbsp;Cloths <input type="radio" name="section" value="Accessories" id="" />  &nbsp;Accessories </dd>
					 </dl> -->
                    <dl>
                        <dt><label for="email">Category Name:</label></dt>
                        <dd><input type="text" name="cat_name" id="" size="54" /></dd>
                    </dl>
                    <dl>
                        <dt><label for="upload">Upload a File:</label></dt>
                        <dd><input type="file" name="cat_image" id="cat_image" /></dd>
                    </dl>
                     <dl class="submit">
                    <input type="submit" name="submit" id="submit" value="Submit" />
                     </dl>
                     
                     
                    
                </fieldset>
                
         </form>
         </div>  
      
     
     </div><!-- end of right content-->
            
                    
  </div>   <!--end of center content -->               
                    
                    
    
    
    <div class="clear"></div>
    </div> <!--end of main content-->
	
 <?php
	require_once('footer.php');
?>      
    

</div>		
</body>
</html>