	<?php
require_once('header.php');
?>
                    
                    
                    
                    
    <div class="center_content">  
    
    
    <?php
	//require_once('sidebar.php');
?>      
    
    <div class="right_content">            
        
    <h2>Edit Content</h2> 
                    
     <?php

$sql = "select * from contect where id='1'";
		$result = mysqli_query($connection,$sql);
		while($row = mysqli_fetch_array($result))
		{
		
		
		?>
     
     
         <div class="form">
         <form action="contentupdate.php" method="post" class="niceform" enctype="multipart/form-data">
         
                <fieldset>
                    <dl>
                        <dt><label for="email">Welcome Title:</label></dt>
                        <dd><input type="text" name="welcome_title" id="welcome_title" size="54" value="<?php echo $row['welcome_title'];?>" /></dd>
                    </dl>
                     <input type="hidden" name="id" value="1" />
					<dd>
				 <dl><dt><label for="email">Welcome Text:</label>	
            <dd><textarea name="welcome_text" id="welcome_text" rows="5" cols="36"><?php echo $row['welcome_text'];?></textarea></dd></dl>
			
			 <dl><dt><label for="email">Banner Text:</label></dt>
                        <dd><input type="text" name="banner_text" id="banner_text" size="54" value="<?php echo $row['banner_text'];?>" /></dd></dl>
						
						<dl><dt><label for="email">Phone No.:</label></dt>
                        <dd><input type="text" name="ph_number" id="ph_number" size="54" value="<?php echo $row['ph_number'];?>" /></dd></dl>
						
						<dl><dt><label for="email">Email:</label></dt>
                        <dd><input type="text" name="email" id="email" size="54" value="<?php echo $row['email'];?>" /></dd></dl>
						
						<dl><dt><label for="email">Address</label></dt>
                        <dd><input type="text" name="address" id="address" size="54" value="<?php echo $row['address'];?>" /></dd></dl>
						
						<dl><dt><label for="email">Vision Text:</label></dt>
                        <dd><input type="text" name="vision_text" id="vision_text" size="54" value="<?php echo $row['vision_text'];?>" /></dd></dl>
          </dd>
                    
                      <dl class="submit">
                    <input type="submit" name="submit" id="submit" value="Submit" />
                     </dl>
                     
                     
                    
                </fieldset>
                
         </form>
         </div>  
      <?php } ?>
	  
	  
     
     </div><!-- end of right content-->
            
                    
  </div>   <!--end of center content -->               
                    
                    
    
    
    <div class="clear"></div>
    </div> <!--end of main content-->
	
 <?php
	require_once('footer.php');
?>      
    

</div>		
</body>
</html>