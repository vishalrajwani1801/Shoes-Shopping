<?php
require_once('connection.php');

echo $cat_name = $_POST['cat_name'];
echo $section = $_POST['section'];

if(!empty($_FILES["cat_image"]["name"])){
		 $filename = time().$_FILES["cat_image"]["name"];
		 move_uploaded_file($_FILES["cat_image"]["tmp_name"],"uploads/".$filename);
		
	}

echo $query = "INSERT INTO `category` (`cat_name`, `section`, `cat_img`) VALUES ('$cat_name','$section', '$filename')";


mysqli_query($connection,$query);

   header('location:dashboard.php');

?>
