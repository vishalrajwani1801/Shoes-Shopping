<?php
session_start();
$id=$_GET['id'];
require_once('connection.php');
require_once('header.php');
?>
                    
                    
                    
                    
    <div class="center_content">  
    
    
    <?php
	//require_once('sidebar.php');
?>      
    
    <div class="right_content">            
        
    <h2>View Product</h2> 
                    
  <?php

$sql = "select * from products where p_id=".$id;
		$result = mysqli_query($connection,$sql);
		while($row = mysqli_fetch_array($result))
		{
		
		//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		?>
                        

         <div class="form">
         <form action="#" method="post" class="niceform" enctype="multipart/form-data">
        <fieldset>
        
        <dl>
          <dt>
            <label for="email">Product Name:</label>
          </dt>
          <dd>
            <input type="text" name="p_name" id="" size="54" value="<?php echo $row['p_name'];?>" disabled="disabled"  />
          </dd>
        </dl>
        <dl>
		
          <dt>
            <label for="upload">Upload a File:</label>
          </dt>
          <dd>
             <img src="puploads/<?php echo $row['p_img'];?>" width="100" height="100" style="border:1px solid;">
          </dd>
		  
		   
		    
        </dl>
        <dl>
          <dt>
            <label for="comments">Product desc:</label>
          </dt>
          <dd>
            <textarea name="p_desc" id="p_desc" rows="5" cols="36" disabled="disabled"><?php echo $row['p_desc'];?></textarea>
          </dd>
        </dl>
		<dl>
          <dt>
            <label for="email">Product Price:</label>
          </dt>
          <dd>
            <input type="text" name="price" id="" size="20" value="<?php echo $row['price'];?>" disabled="disabled"  />
          </dd>
        </dl>
        <dl class="submit">
         <a href="product_listing.php" class="bt">Back</a>
        </dl>
        </fieldset>
      </form>
         </div>  
     <?php } ?>   
     
     </div><!-- end of right content-->
            
                    
  </div>   <!--end of center content -->               
                    
                    
    
    
    <div class="clear"></div>
    </div> <!--end of main content-->
	
 <?php
	require_once('footer.php');
?>      
    

</div>		
</body>
</html>