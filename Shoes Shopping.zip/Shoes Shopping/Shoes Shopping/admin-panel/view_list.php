<?php
session_start();
$id=$_GET['id'];
require_once('connection.php');
require_once('header.php');
?>
                    
                    
                    
                    
    <div class="center_content">  
    
    
    <?php
	//require_once('sidebar.php');
?>      
    
    <div class="right_content">            
        
    <h2>View Buyers List</h2> 
                    
  <?php

$sql = "select * from book where b_id=".$id;
		$result = mysqli_query($connection,$sql);
		while($row = mysqli_fetch_array($result))
		{
		
		//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		?>
                        

         <div class="form">
         <form action="#" method="post" class="niceform" enctype="multipart/form-data">
        <fieldset>
        
        <dl>
          <dt>
            <label for="email">Name:</label>
          </dt>
          <dd>
            <input type="text" name="b_name" id="" size="54" value="<?php echo $row['b_name'];?>" disabled="disabled"  />
          </dd>
        </dl>
		
		 <dl>
          <dt>
            <label for="email">Email:</label>
          </dt>
          <dd>
            <input type="text" name="b_email" id="" size="54" value="<?php echo $row['b_email'];?>" disabled="disabled"  />
          </dd>
        </dl>
		
		 <dl>
          <dt>
            <label for="email">Mobile No.:</label>
          </dt>
          <dd>
            <input type="text" name="b_mobno" id="" size="54" value="<?php echo $row['b_mobno'];?>" disabled="disabled"  />
          </dd>
        </dl>
       
        <dl>
          <dt>
            <label for="comments">Address:</label>
          </dt>
          <dd>
            <textarea name="b_address" id="p_desc" rows="5" cols="36" disabled="disabled"><?php echo $row['b_address'];?></textarea>
          </dd>
        </dl>
        <dl class="submit">
         <a href="buylist.php" class="bt">Back</a>
        </dl>
        </fieldset>
      </form>
         </div>  
     <?php } ?>   
     
     </div><!-- end of right content-->
            
                    
  </div>   <!--end of center content -->               
                    
                    
    
    
    <div class="clear"></div>
    </div> <!--end of main content-->
	
 <?php
	require_once('footer.php');
?>      
    

</div>		
</body>
</html>