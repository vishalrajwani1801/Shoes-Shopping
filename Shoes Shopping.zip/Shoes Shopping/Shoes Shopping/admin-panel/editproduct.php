<?php
session_start();
$id=$_GET['id'];
require_once('connection.php');
require_once('header.php');
?>
                    
                    
                    
                    
    <div class="center_content">  
    
    
    <?php
	//require_once('sidebar.php');
?>      
    
    <div class="right_content">            
        
    <h2>Edit Product</h2> 
                    
  <?php

$sql = "select * from products where p_id=".$id;
		$result = mysqli_query($connection,$sql);
		while($row = mysqli_fetch_array($result))
		{

		?>
                        

         <div class="form">
         <form action="product-update.php" method="post" class="niceform" enctype="multipart/form-data">
        <fieldset>
        <dl>
          <dt>
            <label for="gender">Select categories:</label>
          </dt>
          <dd>
            <select size="1" name="cat_id" id="cat_id">
              <?php
					$kksql = "SELECT * FROM `category`";
					$kkresult = mysqli_query($connection,$kksql);
				    	while($kkrow = mysqli_fetch_array($kkresult))
						{ 
						
						?>
              <option value="<?php echo $kkrow['cat_id'];?>" <?php if($kkrow['cat_id'] == $row['cat_id']) { echo 'selected="selected"'; } ?>><?php echo $kkrow['cat_name'];?></option>
              <?php
					
					  }
					
					?>
            </select>
          </dd>
        </dl>
        <dl>
          <dt>
            <label for="email">Product Name:</label>
          </dt>
          <dd>
            <input type="text" name="p_name" id="" size="54" value="<?php echo $row['p_name'];?>" />
          </dd>
        </dl>
        <dl>
		<input type="hidden" name="p_id" value="<?php echo $row['p_id'];?>" />
					<input type="hidden" name="old_cat_image" value="<?php echo $row['p_img'];?>" />
          <dt>
            <label for="upload">Upload a File:</label>
          </dt>
          <dd>
            <input type="file" name="prod_image" id="prod_image" />
          </dd>
		   <img src="puploads/<?php echo $row['p_img'];?>" width="100" height="100" style="border:1px solid;">
		   
		    old photo
        </dl>
        <dl>
          <dt>
            <label for="comments">Product desc:</label>
          </dt>
          <dd>
            <textarea name="p_desc" id="p_desc" rows="5" cols="36"><?php echo $row['p_desc'];?></textarea>
          </dd>
        </dl>
		 <dl>
          <dt>
            <label for="email">Product Price:</label>
          </dt>
          <dd>
            <input type="text" name="price" id="" size="20" value="<?php echo $row['price'];?>" />
          </dd>
        </dl>
        <dl class="submit">
          <input type="submit" name="submit" id="submit" value="Submit" />
        </dl>
        </fieldset>
      </form>
         </div>  
     <?php } ?>   
     
     </div><!-- end of right content-->
            
                    
  </div>   <!--end of center content -->               
                    
                    
    
    
    <div class="clear"></div>
    </div> <!--end of main content-->
	
 <?php
	require_once('footer.php');
?>      
    

</div>		
</body>
</html>