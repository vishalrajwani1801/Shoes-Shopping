<?php
session_start();
$id=$_GET['id'];
require_once('connection.php');
require_once('header.php');
?>
                    
                    
                    
                    
    <div class="center_content">  
    
    
    <?php
	//require_once('sidebar.php');
?>      
    
    <div class="right_content">            
        
    <h2>View Category</h2> 
                    
     <?php

$sql = "select * from category where cat_id=".$id;
		$result = mysqli_query($connection,$sql);
		while($row = mysqli_fetch_array($result))
		{
		
		//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		?>
     
     
         <div class="form">
         <form action="dashboard.php" method="post" class="niceform" >
         
                <fieldset>
				 <dl>
                        <dt><label for="email">Section:</label></dt>
                        <dd><input type="text" name="section" id="" size="54" value="<?php echo $row['section'];?>" disabled="disabled" /></dd>
                    </dl>
                    <dl>
                        <dt><label for="email">Category Name:</label></dt>
                        <dd><input type="text" name="cat_name" id="" size="54" value="<?php echo $row['cat_name'];?>" disabled="disabled" /></dd>
                    </dl>
                     
                    <dl>
                        <dt><label for="upload">Upload a File:</label></dt>
                        <dd><img src="uploads/<?php echo $row['cat_img'];?>" width="100" height="100" style="border:1px solid;"></dd> 
						 
					 
                    </dl>
                      <dl class="submit">
                    
					<a href="dashboard.php" class="bt">Back</a>
                     </dl>
                     
                     
                    
                </fieldset>
                
         </form>
         </div>  
      <?php } ?>
     
     </div><!-- end of right content-->
            
                    
  </div>   <!--end of center content -->               
                    
                    
    
    
    <div class="clear"></div>
    </div> <!--end of main content-->
	
 <?php
	require_once('footer.php');
?>      
    

</div>		
</body>
</html>