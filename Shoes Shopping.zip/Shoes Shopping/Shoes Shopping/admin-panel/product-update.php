<?php
include("connection.php");
$id = $_POST['p_id'];


$p_name = $_POST['p_name'];
$p_desc = $_POST['p_desc'];
$price = $_POST['price'];
$cat_id = $_POST['cat_id'];
$old_cat_image = $_POST['old_cat_image'];

	echo $_FILES["prod_image"]['name'];
//	exit;
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//@@@
if($_FILES["prod_image"]['name'] != '') {
if(isset($_FILES["prod_image"]["tmp_name"]))
	{
		$tmp_filename = $_FILES["prod_image"]["tmp_name"];
	}
	//Original Image upload.
$filename = time().$_FILES["prod_image"]["name"];
		 move_uploaded_file($_FILES["prod_image"]["tmp_name"],"puploads/".$filename);
}
else { 
$filename = $old_cat_image; 
}
//@@@


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

	 echo $query="UPDATE products SET cat_id = '$cat_id' , p_name = '$p_name', p_desc = '$p_desc', price = '$price', p_img = '$filename' WHERE p_id = ".$id;
		
				mysqli_query($connection,$query);
				?>
				
			 <?php
			 header("location:product_listing.php");

?>