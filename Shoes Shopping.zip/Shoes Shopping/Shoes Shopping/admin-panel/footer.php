<div class="footer">
    
    	<div class="left_footer">ADMIN PANEL | Powered by Vishal Rajwani & Yashrajsinh Jethwa</div>
    	
    
    </div>