<?php
session_start();
require_once('connection.php');
require_once('header.php');
?>
                    
                    
                    
                    
    <div class="center_content">  
    
       
    
    <div class="right_content">            
        
    <h2>Contact Listing</h2> 
                    
                    
<table id="rounded-corner" summary="2007 Major IT Companies' Profit">
    <thead>
    	<tr>
        	
            <th scope="col" class="rounded">Sr. No</th>
            <th scope="col" class="rounded">First Name</th>
			<th scope="col" class="rounded">Last Name</th>
			<th scope="col" class="rounded">Email</th>
			<th scope="col" class="rounded">Phone No.</th>
			<th scope="col" class="rounded">View</th>
            <th scope="col" class="rounded-q4">Delete</th>
        </tr>
    </thead>
        
    <tbody>
	<?php
					$sql = "SELECT * FROM `contact`";
					$result = mysqli_query($connection,$sql);
					$i = 1;

					
				    	while($row = mysqli_fetch_array($result))
						{ 
						 
						?>
    	<tr>
        	<td><?php echo $i; ?></td>
            <td><?php echo $row['name'];?></td>
			 <td><?php echo $row['lname'];?></td>
			 <td><?php echo $row['email'];?></td>
			  <td><?php echo $row['mobile'];?></td>
<td><a href="contact_view.php?id=<?php echo $row['id'];?>"><img src="images/info.png" alt="" title="" border="0" /></a></td>
            <td><a href="contact_delete.php?id=<?php echo $row['id'];?>" class="ask"><img src="images/trash.png" alt="" title="" border="0" /></a></td>
        </tr>
        
    	  <?php
					
					 
					   $i++;
					  }
					
					?>
        
    	    
        
    </tbody>
</table>
     
    
     
     
         
      
     
     </div><!-- end of right content-->
            
                    
  </div>   <!--end of center content -->               
                    
                    
    
    
    <div class="clear"></div>
    </div> <!--end of main content-->
	
 <?php
	require_once('footer.php');
?>      
    

</div>		
</body>
</html>>
