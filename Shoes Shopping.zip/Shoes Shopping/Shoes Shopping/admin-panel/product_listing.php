<?php
session_start();
require_once('connection.php');
require_once('header.php');
?>
                    
                    
                    
                    
    <div class="center_content">  
    
    
    <?php
	//require_once('sidebar.php');
?>      
    
    <div class="right_content">            
        
    <h2>Products Settings</h2> 
                    
                    
<table id="rounded-corner" summary="2007 Major IT Companies' Profit">
    <thead>
    	<tr>
        	
            <th scope="col" class="rounded">Sr. No</th>
            <th scope="col" class="rounded">Category Name</th>
            <th scope="col" class="rounded">Product Name</th>
            <th scope="col" class="rounded">Product Image</th>
			 <th scope="col" class="rounded">Product Price</th>
			<th scope="col" class="rounded">View</th>
            <th scope="col" class="rounded">Edit</th>
            <th scope="col" class="rounded-q4">Delete</th>
        </tr>
    </thead>
        
    <tbody>
	<?php
					$sql = "SELECT * FROM `products`";
					$result = mysqli_query($connection,$sql);
					$i = 1;

					
				    	while($row = mysqli_fetch_array($result))
						{ 
						 $cid = $row['cat_id'];
						$ksql = "SELECT * FROM `category` where cat_id = '$cid'";
					$kresult = mysqli_query($connection,$ksql);
				

					
				    	while($krow = mysqli_fetch_array($kresult))
						{ 
						?>
    	<tr>
        	<td><?php echo $i; ?></td>
            <td><?php echo $krow['cat_name'];?></td>
            <td><?php echo $row['p_name'];?></td>
            <td><img src="puploads/<?php echo $row['p_img'];?>" alt="" title="" border="0" height="50" width="50" /></td>
			 <td><?php echo $row['price'];?></td>
<td><a href="view-prod.php?id=<?php echo $row['p_id'];?>"><img src="images/info.png" alt="" title="" border="0" /></a></td>
            <td><a href="editproduct.php?id=<?php echo $row['p_id'];?>"><img src="images/user_edit.png" alt="" title="" border="0" /></a></td>
            <td><a href="product_delete.php?id=<?php echo $row['p_id'];?>" class="ask"><img src="images/trash.png" alt="" title="" border="0" /></a></td>
        </tr>
        
    	  <?php
					
					  } 
					   $i++;
					  }
					
					?>
        
    	    
        
    </tbody>
</table>

	 <a href="addproduct.php" class="bt_green"><span class="bt_green_lft"></span><strong>Add new item</strong><span class="bt_green_r"></span></a>
     
    
     
     
         
      
     
     </div><!-- end of right content-->
            
                    
  </div>   <!--end of center content -->               
                    
                    
    
    
    <div class="clear"></div>
    </div> <!--end of main content-->
	
 <?php
	require_once('footer.php');
?>      
    

</div>		
</body>
</html>