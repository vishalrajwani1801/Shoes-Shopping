<div class="left_content">
    
    		
    
            <div class="sidebarmenu">
            
               
                <a class="menuitem submenuheader" href="" >Sidebar Settings</a>
                <div class="submenu">
                    <ul>
                    <li><a href="">Sidebar submenu</a></li>
                    <li><a href="">Sidebar submenu</a></li>
                    <li><a href="">Sidebar submenu</a></li>
                    <li><a href="">Sidebar submenu</a></li>
                    <li><a href="">Sidebar submenu</a></li>
                    </ul>
                </div>
                <a class="menuitem submenuheader" href="">Add new products</a>
                <div class="submenu">
                    <ul>
                    <li><a href="">Sidebar submenu</a></li>
                    <li><a href="">Sidebar submenu</a></li>
                    <li><a href="">Sidebar submenu</a></li>
                    <li><a href="">Sidebar submenu</a></li>
                    <li><a href="">Sidebar submenu</a></li>
                    </ul>
                </div>
               
                    
            </div>
            
            
            
            
            
            
              
            
            
              
    
    </div>