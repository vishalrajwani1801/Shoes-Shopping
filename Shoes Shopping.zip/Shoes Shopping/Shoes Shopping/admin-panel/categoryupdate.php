<?php
include("connection.php");
$id = $_POST['cat_id'];



//

$cat_name = $_POST['cat_name'];
$section = $_POST['section'];
$old_cat_image = $_POST['old_cat_image'];

	echo $_FILES["cat_image"]['name'];
//	exit;
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//@@@
if($_FILES["cat_image"]['name'] != '') {
if(isset($_FILES["cat_image"]["tmp_name"]))
	{
		$tmp_filename = $_FILES["cat_image"]["tmp_name"];
	}
	//Original Image upload.
$filename = time().$_FILES["cat_image"]["name"];
		 move_uploaded_file($_FILES["cat_image"]["tmp_name"],"uploads/".$filename);
}
else { 
$filename = $old_cat_image; 
}
//@@@


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

	 $query="UPDATE category SET 
			
				cat_name = '$cat_name' , section = '$section', cat_img = '$filename'
				WHERE cat_id = ".$id;
			
				mysqli_query($connection,$query);
				?>
				
			 <?php
			 header("location:dashboard.php");

?>