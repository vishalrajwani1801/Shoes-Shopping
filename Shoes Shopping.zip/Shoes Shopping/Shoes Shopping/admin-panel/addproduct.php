<?php
session_start();
require_once('connection.php');
require_once('header.php');
?>

<div class="center_content">
  <?php
	//require_once('sidebar.php');
?>
  <div class="right_content">
    <h2>Add New Products</h2>
    <div class="form">
      <form action="product-exe.php" method="post" class="niceform" enctype="multipart/form-data">
        <fieldset>
        <dl>
          <dt>
            <label for="gender">Select categories:</label>
          </dt>
          <dd>
            <select size="1" name="cat_id" id="cat_id">
              <?php
					$sql = "SELECT * FROM `category`";
					$result = mysqli_query($connection,$sql);
				    	while($row = mysqli_fetch_array($result))
						{ 
						
						?>
              <option value="<?php echo $row['cat_id'];?>"><?php echo $row['cat_name'];?></option>
              <?php
					
					  }
					
					?>
            </select>
          </dd>
        </dl>
        <dl>
          <dt>
            <label for="email">Product Name:</label>
          </dt>
          <dd>
            <input type="text" name="p_name" id="" size="54" />
          </dd>
        </dl>
        <dl>
          <dt>
            <label for="upload">Upload a File:</label>
          </dt>
          <dd>
            <input type="file" name="prod_image" id="prod_image" />
          </dd>
        </dl>
        <dl>
          <dt>
            <label for="comments">Product desc:</label>
          </dt>
          <dd>
            <textarea name="p_desc" id="p_desc" rows="5" cols="36"></textarea>
          </dd>
        </dl>
		 <dl>
          <dt>
            <label for="email">Product Price:</label>
          </dt>
          <dd>
            <input type="text" name="price" id="" size="20" />
          </dd>
        </dl>
        <dl class="submit">
          <input type="submit" name="submit" id="submit" value="Submit" />
        </dl>
        </fieldset>
      </form>
    </div>
  </div>
  <!-- end of right content-->
</div>
<!--end of center content -->
<div class="clear"></div>
</div>
<!--end of main content-->
<?php
	require_once('footer.php');
?>
</div>
</body></html>