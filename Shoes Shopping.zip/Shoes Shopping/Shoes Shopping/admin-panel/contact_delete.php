<?php
include("connection.php");
$id=$_GET['id'];


$kksql = "delete from contact where id=".$id;
$kkresult = mysqli_query($connection,$kksql);

						header("location:contact_list.php");
?>