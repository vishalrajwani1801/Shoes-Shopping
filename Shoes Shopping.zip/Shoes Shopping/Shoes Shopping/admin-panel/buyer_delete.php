<?php
include("connection.php");
$id=$_GET['id'];


$kksql = "delete from book where b_id=".$id;
$kkresult = mysqli_query($connection,$kksql);

						?>
				<?php
						header("location:buylist.php");
?>