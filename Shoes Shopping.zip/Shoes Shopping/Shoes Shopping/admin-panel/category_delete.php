<?php
include("connection.php");
$id=$_GET['id'];

$sql = "delete from category where cat_id=".$id;
$result = mysqli_query($connection,$sql);

$kksql = "delete from products where cat_id=".$id;
$kkresult = mysqli_query($connection,$kksql);

						?>
				<?php
						header("location:dashboard.php");
?>