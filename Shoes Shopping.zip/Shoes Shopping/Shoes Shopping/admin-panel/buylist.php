<?php
session_start();
require_once('connection.php');
require_once('header.php');
$id=$_GET['id'];
?>
                    
                    
                    
                    
    <div class="center_content">  
    
    
    <?php
	//require_once('sidebar.php');
?>      
    
    <div class="right_content">            
        
    <h2>Buy List</h2> 
                    
                    
<table id="rounded-corner" summary="2007 Major IT Companies' Profit">
    <thead>
    	<tr>
        	
            <th scope="col" class="rounded">Sr. No</th>
            <th scope="col" class="rounded">Name</th>
            <th scope="col" class="rounded">Product Name</th>
            <th scope="col" class="rounded">Mobile No.</th>
			<th scope="col" class="rounded">View</th>
            <th scope="col" class="rounded-q4">Delete</th>
        </tr>
    </thead>
        
    <tbody>
	<?php
					$sql = "SELECT * FROM `book`";
					$result = mysqli_query($connection,$sql);
					$i = 1;

					
				    	while($row = mysqli_fetch_array($result))
						{
					$cid = $row['p_id'];
						$ksql = "SELECT * FROM `products` where p_id = '$cid'";
					$kresult = mysqli_query($connection,$ksql);
				

					
				    	while($krow = mysqli_fetch_array($kresult))
						{ 
						?>
    	<tr>
        	<td><?php echo $i; ?></td>
            <td><?php echo $krow['p_name'];?></td>
            <td><?php echo $row['b_email'];?></td>
			 <td><?php echo $row['b_mobno'];?></td>
<td><a href="view_list.php?id=<?php echo $row['b_id'];?>"><img src="images/info.png" alt="" title="" border="0" /></a></td>
            <td><a href="buyer_delete.php?id=<?php echo $row['b_id'];?>" class="ask"><img src="images/trash.png" alt="" title="" border="0" /></a></td>
        </tr>
        
    	  <?php
		  			}
					   $i++;
					  
					}
					?>
        
    	    
        
    </tbody>
</table>

	
     
    
     
     
         
      
     
     </div><!-- end of right content-->
            
                    
  </div>   <!--end of center content -->               
                    
                    
    
    
    <div class="clear"></div>
    </div> <!--end of main content-->
	
 <?php
	require_once('footer.php');
?>      
    

</div>		
</body>
</html>