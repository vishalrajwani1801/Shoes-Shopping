<?php
session_start();
echo $id=$_GET['id'];
require_once('connection.php');
require_once('header.php');
?>
                    
                    
                    
                    
    <div class="center_content">  
    
    
    <?php
	//require_once('sidebar.php');
?>      
    
    <div class="right_content">            
        
    <h2>View</h2> 
                    
  <?php

$sql = "select * from contact where id=".$id;
		$result = mysqli_query($connection,$sql);
		while($row = mysqli_fetch_array($result))
		{
		
		//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		?>
                        

         <div class="form">
         <form action="#" method="post" class="niceform" enctype="multipart/form-data">
        <fieldset>
        
        <dl>
          <dt>
            <label for="email">Firt Name:</label>
          </dt>
          <dd>
            <input type="text" name="c_name" id="" size="54" value="<?php echo $row['name'];?>" disabled="disabled"  />
          </dd>
        </dl>
		
		 <dl>
          <dt>
            <label for="email">Last Name:</label>
          </dt>
          <dd>
            <input type="text" name="c_name" id="" size="54" value="<?php echo $row['lname'];?>" disabled="disabled"  />
          </dd>
        </dl>
        
       
		
		 <dl>
          <dt>
            <label for="email">Email:</label>
          </dt>
          <dd>
            <input type="text" name="c_email" id="" size="54" value="<?php echo $row['email'];?>" disabled="disabled"  />
          </dd>
        </dl>
		
		<dl>
          <dt>
            <label for="email">Phone No:</label>
          </dt>
          <dd>
            <input type="text" name="c_email" id="" size="54" value="<?php echo $row['mobile'];?>" disabled="disabled"  />
          </dd>
        </dl>
		
		 <dl>
          <dt>
            <label for="comments">Message:</label>
          </dt>
          <dd>
            <textarea name="c_message" id="p_desc" rows="5" cols="36" disabled="disabled"><?php echo $row['comment'];?></textarea>
          </dd>
        </dl>
        <dl class="submit">
         <a href="contact_list.php" class="bt">Back</a>
        </dl>
        </fieldset>
      </form>
         </div>  
     <?php } ?>   
     
     </div><!-- end of right content-->
            
                    
  </div>   <!--end of center content -->               
                    
                    
    
    
    <div class="clear"></div>
    </div> <!--end of main content-->
	
 <?php
	require_once('footer.php');
?>      
    

</div>		
</body>
</html>