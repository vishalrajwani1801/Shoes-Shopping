<?php
session_start();
$id=$_GET['id'];
require_once('connection.php');
require_once('header.php');
?>
                    
                    
                    
                    
    <div class="center_content">  
    
    
    <?php
	//require_once('sidebar.php');
?>      
    
    <div class="right_content">            
        
    <h2>Edit Category</h2> 
                    
     <?php

$sql = "select * from category where cat_id=".$id;
		$result = mysqli_query($connection, $sql);
		while($row = mysqli_fetch_array($result))
		{
		
		//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		?>
     
     
         <div class="form">
         <form action="categoryupdate.php" method="post" class="niceform" enctype="multipart/form-data">
         
                <fieldset>
				<dl>
					 <dt><label for="email">Section:</label></dt>
					 <dd><input type="radio" name="section" value="Cloths" id="" <?php if($row['section'] == 'Cloths' ) { echo 'checked="checked"'; } ?> />  &nbsp;Cloths 
					 <input type="radio" name="section" value="Accessories" id="" <?php if($row['section'] == 'Accessories' ) { echo 'checked="checked"'; } ?> />  &nbsp;Accessories </dd>
					 </dl>
                    <dl>
                        <dt><label for="email">Category Name:</label></dt>
                        <dd><input type="text" name="cat_name" id="" size="54" value="<?php echo $row['cat_name'];?>" /></dd>
                    </dl>
                     <input type="hidden" name="cat_id" value="<?php echo $row['cat_id'];?>" />
					<input type="hidden" name="old_cat_image" value="<?php echo $row['cat_img'];?>" />
                    <dl>
                        <dt><label for="upload">Upload a File:</label></dt>
                        <dd><input type="file" name="cat_image" id="cat_image" /></dd> 
						 <img src="uploads/<?php echo $row['cat_img'];?>" width="100" height="100" style="border:1px solid;">
					  old photo
                    </dl>
                      <dl class="submit">
                    <input type="submit" name="submit" id="submit" value="Submit" />
                     </dl>
                     
                     
                    
                </fieldset>
                
         </form>
         </div>  
      <?php } ?>
     
     </div><!-- end of right content-->
            
                    
  </div>   <!--end of center content -->               
                    
                    
    
    
    <div class="clear"></div>
    </div> <!--end of main content-->
	
 <?php
	require_once('footer.php');
?>      
    

</div>		
</body>
</html>