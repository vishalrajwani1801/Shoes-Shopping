<?php
	require_once('connection.php');
	require_once('header.php');
?>


<div class="aa">
<br />
	<center><h1>Contact Us</h1></center>
	</div>
	
	<div class="register">
		<div class="container">
	 		
<center>	 			<h3>CONTACT INFORMATION</h3><br></center>
	<?php
		$sql = "SELECT * FROM `contect`";
		$result = mysqli_query($connection,$sql);
		$i = 1;
		while($row = mysqli_fetch_array($result))
		{
	?>
	 				<div class="col-md-4">
						Phone No.<div class="verticalLineTop"></div><br>
						<?php echo $row['ph_number']; ?>
	 				</div>
					<div class="col-md-4">
						Email<div class="verticalLineTop"></div><br>
						<?php echo $row['email']; ?>
	 				</div>
					<div class="col-md-4">
						Address<div class="verticalLineTop"></div><br>
						<?php echo $row['address']; ?>
	 				</div>
		<?php
			$i++;
			}
		?> 	
		</div>
	</div>
	<div class="register">
		<div class="container">
		   <form action="contact_ins.php" method="post" name="nm"> 
				 <div class="register-top-grid">
					<h1>PERSONAL INFORMATION</h1>
					 <div>
						<span>First Name<label>*</label></span>
						<input type="text" name="c_fn" /> 
					 </div>
					 <div>
						<span>Last Name<label>*</label></span>
						<input type="text" name="c_ln" /> 
					 </div>
					 <div>
						 <span>Email<label>*</label></span>
						 <input type="text" name="c_email" /> 
					 </div>
					 <div>
						<span>Phone No.<label>*</label></span>
						<input type="text" name="c_pn" /> 
					 </div>
					 
					 <div class="">
					 <span>Message<label>*</label></span>
					   <textarea class="textarea1" name="c_message" style="width:1080px"></textarea>
					   </div>
					   <div class="clearfix"> </div>
					 </div>
				   <div class="clearfix"> </div>
				<div class="register-but">
				  
					   <input type="submit" value="submit">
				   
				</div>  
				</form>
				
		   </div>
	</div>


<?php
	require_once('footer.php');
?>