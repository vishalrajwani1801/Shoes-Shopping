<?php
	$id=$_GET['id'];
	require_once('header.php');
?>


<header class="section background-primary text-center">
            <h1 class="text-white margin-bottom-0 text-size-50 text-thin text-line-height-1">Product List
 
</h1>
        </header>
	<div class="pad">
	<div class="container">
	<?php
					$sql = "SELECT * FROM `products` where  cat_id=".$id;
					$result = mysqli_query($connection,$sql);
					$i = 1;

					
				    	while($row = mysqli_fetch_array($result))
						{ 
						 
						?>
<table align="center"><tr>
<tt>	
<div class="col-md-3">



	<a href="desc.php?id=<?php echo $row['p_id'];?>"><img style="width:200px;height:150px;" src="admin-panel/puploads/<?php echo $row['p_img'];?>" class="img-responsive img1"  height="250px" width="300px" alt=""/>
			<h2 class="size" style="text-align:center;"><a href="desc.php?id=<?php echo $row['p_id'];?>"><?php echo $row['p_name'];?></a></h2>
			<h2 class="size" style="text-align:center;">Price: <?php echo $row['price'];?> </h2>

</div>
</table>

	<?php
					
					 
					   $i++;
					  }
					
					?>
		<div class="clearfix"> </div>
		</div>
	</div>



<?php
	require_once('footer.php');
?>