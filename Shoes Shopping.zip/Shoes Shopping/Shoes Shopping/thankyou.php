<?php
	header("refresh:2;url=index.php");
	require_once('header.php');
?>

<div class="container" style="text-align:center; padding:250px;">
<h1> THANK YOU FOR BUYING.............</h1>

</div>

<?php
	require_once('footer.php');
?>
