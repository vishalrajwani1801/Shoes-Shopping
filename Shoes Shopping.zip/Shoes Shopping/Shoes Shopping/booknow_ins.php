<?php
	require_once('connection.php');
	
$p_id = $_POST['p_id'];	
$b_name = $_POST['b_name'];
$b_email = $_POST['b_email'];
$b_mobno = $_POST['b_mobno'];
$b_address = $_POST['b_address'];

$insert = "INSERT INTO `book` (`p_id`, `b_name`, `b_email`, `b_mobno`, `b_address`) VALUES ('$p_id', '$b_name', '$b_email', '$b_mobno', '$b_address')";
mysqli_query($connection,$insert);

header('location:thankyou.php');

?>