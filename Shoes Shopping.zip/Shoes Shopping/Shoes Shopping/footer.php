<div class="footer">
		<!-- container -->
		<div class="container">
			<div class="col-md-3 footer-left">
			<h3>Quick Links<div class="verticalLineTop"></div></h3>
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="about.php">About Us</a></li>
					<li><a href="contact.php">Contact Us</a></li>
				</ul>
					
			</div>
			<div class="col-md-3 footer-left">
			<h3>Products<div class="verticalLineTop"></div></h3>
				<ul>
				<?php
					$sql = "SELECT * FROM `products` ORDER BY p_id DESC LIMIT 0,3";
					$result = mysqli_query($connection,$sql);
					$i = 1;

					
				    	while($row = mysqli_fetch_array($result))
						{ 
						 
						?>
					<li><a href="desc.php?id=<?php echo $row['p_id'];?>"><?php echo $row['p_name'];?></a></li>
					 <?php
					
					 
					   $i++;
					  }
					
					?>
				</ul>
					
			</div>
			<div class="col-md-3 footer-middle">
				<h3>Address<div class="verticalLineTop"></div></h3>
				<?php
					$sql = "SELECT * FROM `contect`";
					$result = mysqli_query($connection,$sql);
					$i = 1;
				    	while($row = mysqli_fetch_array($result))
						{ 
						 
						?>
				<div class="address">
				 <p><b>Address:</b><?php echo $row['address']; ?></p>
				</div>
				<div class="phone">
					<p><b>Phone: </b><?php echo $row['ph_number']; ?></p>
				</div>
				<div class="email">
					<p><b>Email: </b><a href="#"><?php echo $row['email']; ?></a></p>
				</div>
				 <?php
					   $i++;
					  }
					
					?>
			</div>
			<div class="col-md-3 footer-right">
				<h2>Our Vision<div class="verticalLineTop"></div></h2>
				<?php
					$sql = "SELECT * FROM `contect`";
					$result = mysqli_query($connection,$sql);
					$i = 1;
				    	while($row = mysqli_fetch_array($result))
						{ 
						 
						?>
				<p><?php echo $row['vision_text']; ?></p>
				 <?php
					
					 
					   $i++;
					  }
					
					?>
			</div>
			<div class="clearfix"> </div>	
		</div>
		<!-- //container -->
	</div>
	<!--<---//Footer---->
	<div class="grid_3">
	  <div class="container hov">
	  	 
         <p>Copyright � 2019 ShoeShopping. All Rights Reserved | Developed by Vishal Rajwani & YashrajSinh Jethwa</a> </p>
	  </div>
	</div>
</body>
</html>		