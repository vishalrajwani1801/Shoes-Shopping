-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 01, 2019 at 09:22 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoes`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE `admin_tbl` (
  `admin_id` int(15) NOT NULL,
  `user_nm` varchar(200) NOT NULL,
  `pass` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`admin_id`, `user_nm`, `pass`) VALUES
(1, 'vishal', 'vishal123'),
(2, 'admin', 'admin123'),
(3, 'yashraj', 'yashraj123');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `b_id` int(15) NOT NULL,
  `b_name` varchar(100) NOT NULL,
  `b_email` varchar(100) NOT NULL,
  `b_mobno` varchar(15) NOT NULL,
  `b_address` varchar(500) NOT NULL,
  `p_id` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`b_id`, `b_name`, `b_email`, `b_mobno`, `b_address`, `p_id`) VALUES
(2, 'Pavan', 'asharapavan@yahoo.com', '9408533355', 'NANDANWAN PArk.', 0),
(3, 'Kishan', 'kishan.punjani@gmail.com', '9924646831', 'Patel Colony', 0),
(5, 'KISHAN', 'KISHAN@YAHOO.COM', '9926565899', 'ABC', 15),
(6, 'zzz', 'zzz', '123', 'zzz', 15),
(7, 'pr1', 'pr', '23232323232', 'patel', 20),
(8, 'Pavan', 'kishan.punjani@gmail.com', '9408533355', 'ABC', 20),
(9, 'Pavan', 'kishan.punjani@gmail.com', '9408533355', 'ASDF', 20),
(10, 'Pavan', 'asharapavan@yahoo.com', '9408533355', 'PATEL', 20),
(11, 'Pavan', 'kishan.punjani@gmail.com', '9408533355', 'aaaaa', 20),
(12, 'Pavan', 'asharapavan@yahoo.com', '9924646831', 'asasas', 20),
(14, 'abc', 'def', '1234', 'abcd', 17),
(15, 'abc', 'def', '1234', 'cafa', 3),
(16, 'abc', 'def', '1234', 'dad', 19),
(17, 'abc', 'xyz', '1234567890', 'ABCD', 22),
(18, 'vishal', 'vishal14@gmail.com', '9898628524', 'hapa , jamnagar', 36),
(19, 'abv', 'abc@gmail.com', '123456789', 'abc', 23);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(15) NOT NULL,
  `cat_name` varchar(200) NOT NULL,
  `cat_img` varchar(200) NOT NULL,
  `section` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`, `cat_img`, `section`) VALUES
(11, 'Metro', '1568617254metro-shoes-logo-min.png', ''),
(12, 'Mochi', '1568617323download.png', ''),
(13, 'Liberty ', '1568617062logo.png', ''),
(14, 'Khadim', '1568617176logo.gif', '');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(15) NOT NULL,
  `name` varchar(80) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `comment` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `lname`, `email`, `mobile`, `comment`) VALUES
(4, 'ABC', 'DEF', 'ABC@DEF.COM', '1237894560', 'DEF');

-- --------------------------------------------------------

--
-- Table structure for table `contect`
--

CREATE TABLE `contect` (
  `id` int(15) NOT NULL,
  `welcome_title` varchar(200) NOT NULL,
  `welcome_text` longtext NOT NULL,
  `banner_text` varchar(150) NOT NULL,
  `ph_number` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `vision_text` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contect`
--

INSERT INTO `contect` (`id`, `welcome_title`, `welcome_text`, `banner_text`, `ph_number`, `email`, `address`, `vision_text`) VALUES
(1, 'Welcome To Shoes Shopping', '<i>Be the first to hear about new releases, special shoes and more.</i>', 'Lot of fun, not even a bit of it will disappoint you.', '9924647799', 'ShoeShopping@gmail.com', 'H J Doshi Info. Tech Institute College , Jamnagar ', '<b>We will serve you with our best quality of service and not even a bit of it will disappoint you.</b>');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `p_id` int(15) NOT NULL,
  `cat_id` int(15) NOT NULL,
  `p_name` varchar(100) NOT NULL,
  `p_desc` varchar(300) NOT NULL,
  `p_img` varchar(200) NOT NULL,
  `price` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`p_id`, `cat_id`, `p_name`, `p_desc`, `p_img`, `price`) VALUES
(23, 11, ' Casual Shoe', '<h1><i>Metro</i></h1><br>\r\nMetro Casual  Shoe For Men (Black)\r\n<br><br><h3><b>Services:</b><br><p>1) 30 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  1 Month <br><br>Delivery: <p> Usually Delivered in 3-4 days</p>', '1568556830casual1.jpg', '2499'),
(24, 11, 'Sneakers Shoe', '<h1><i>Metro</i></h1><br>\r\nMetro Sneakers Shoe For Men (White)\r\n<br><br><h3><b>Services:</b><br><p>1) 30 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  1 Month <br><br>Delivery: <p> Usually Delivered in 3-4 days</p>', '1568557646Sneakers.jpg', '2699'),
(25, 11, 'Sports Shoe', '<h1><i>Metro</i></h1><br>\r\nMetro Sports Shoe For Men (Blue)<p>Running Shoe</p> <h3><b>Services:</b><br><p>1) 30 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  1 Month <br><br>Delivery: <p> Usually Delivered in 3-4 days</p>', '1568557802sports3.jpg', '1999'),
(26, 11, 'Formal Shoe', '<h1><i>Metro</i></h1><br>\r\nMetro Formal Shoe For Men (Black)\r\n<p>Party Wear Shoe</p><h3><b>Services:</b><br><p>1) 30 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  1 Month <br><br>Delivery: <p> Usually Delivered in 3-4 days</p>', '1568558044formal1.jpg', '2229'),
(27, 11, ' Casual Shoe', '<h1><i>Metro</i></h1><br>\r\nMetro Casual  Shoe For Men (Black)\r\n<br><br><h3><b>Services:</b><br><p>1) 30 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  1 Month <br><br>Delivery: <p> Usually Delivered in 3-4 days</p>', '1568558088casual2.jpg', '2129'),
(28, 11, 'Sneakers Shoe', '<h1><i>Metro</i></h1><br>\r\nMetro Sneakers Shoe For Men (Blue)\r\n<br><br><h3><b>Services:</b><br><p>1) 30 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  1 Month <br><br>Delivery: <p> Usually Delivered in 3-4 days</p>', '1568558144Sneakers2.jpg', '2303'),
(29, 11, 'Sports Shoe', '<h1><i>Metro</i></h1><br>\r\nMetro Sports Shoe For Men (Red)<p>Running Shoe<br>Special price</p> <h3><b>Services:</b><br><p>1) 30 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  1 Month <br><br>Delivery: <p> Usually Delivered in 3-4 days</p>', '1568558306sports.jpg', '2349'),
(30, 11, 'Formal Shoe', '<h1><i>Metro</i></h1><br>\r\nMetro Formal Shoe For Men (Black)\r\n<p>Party Wear Shoe<br>Special material </p><h3><b>Services:</b><br><p>1) 30 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  1 Month <br><br>Delivery: <p> Usually Delivered in 3-4 days</p>', '1568558534formal2.jpg', '2499'),
(31, 11, ' Casual Shoe', '<h1><i>Metro</i></h1><br>\r\nMetro Casual  Shoe For Men (Black)\r\n<br><br><h3><b>Services:</b><br><p>1) 30 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  1 Month <br><br>Delivery: <p> Usually Delivered in 3-4 days</p>', '1568558605casual3.jpg', '1879'),
(32, 11, 'Sneakers Shoe', '<h1><i>Metro</i></h1><br>\r\nMetro Sneakers Shoe For Men (Blue)\r\n<br><br><h3><b>Services:</b><br><p>1) 30 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  1 Month <br><br>Delivery: <p> Usually Delivered in 3-4 days</p>', '1568558732Sneakers3.jpg', '2266'),
(33, 11, 'Sports Shoe', '<h1><i>Metro</i></h1><br>\r\nMetro Sports Shoe For Men <p>Special Shoe </p> <h3><b>Services:</b><br><p>1) 30 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  1 Month <br><br>Delivery: <p> Usually Delivered in 3-4 days</p>', '1568558807sports2.jpg', '2699'),
(34, 11, 'Formal Shoe', '<h1><i>Metro</i></h1><br>\r\nMetro Formal Shoe For Men (Tan)\r\n<p>Party Wear Shoe</p><h3><b>Services:</b><br><p>1) 30 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  1 Month <br><br>Delivery: <p> Usually Delivered in 3-4 days</p>', '1568617394formal.jpg', '2303'),
(35, 12, 'Formal Shoe', '<h1><i>Mochi</i></h1><br>\r\nMochi Formal Shoe For Men (Black)\r\n<P>Party Wear Shoe<br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568559257formal 2.jpg', '3866'),
(36, 12, ' Casual Shoe', '<h1><i>Mochi</i></h1><br>\r\nMochi Casual Shoe For Men (Blue)\r\n<P>Awesome Shoe <br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568559395casual.jpg', '3199'),
(37, 12, 'Sneakers Shoe', '<h1><i>Mochi</i></h1><br>\r\nMochi Sneakers Shoe For Men (White)\r\n<br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568559518Sneakers2.jpg', '2999'),
(38, 12, 'Sports Shoe', '<h1><i>Mochi</i></h1><br>\r\nMochi Sports Shoe For Men (Blue)\r\n<P>Running Shoe<br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568559653sports1.jpg', '3129'),
(39, 12, 'Formal Shoe', '<h1><i>Mochi</i></h1><br>\r\nMochi Formal Shoe For Men (Tan)\r\n<br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568559759formal 4.jpg', '3100'),
(40, 12, ' Casual Shoe', '<h1><i>Mochi</i></h1><br>\r\nMochi Casual Shoe For Men (Black)\r\n<P>Simple Shoe <br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568559942casual2.jpg', '2989'),
(41, 12, 'Sneakers Shoe', '<h1><i>Mochi</i></h1><br>\r\nMochi Sneakers Shoe For Men (White & Silver)\r\n<br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568560037Sneakers3.jpg', '2699'),
(42, 12, 'Sports Shoe', '<h1><i>Mochi</i></h1><br>\r\nMochi Sports Shoe For Men (Black)\r\n<P>Running Shoe<br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568560171sports3.jpg', '2859'),
(43, 12, 'Formal Shoe', '<h1><i>Mochi</i></h1><br>\r\nMochi Formal Shoe For Men (Black)\r\n<P>Regular Shoe<br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568560388formal.jpg', '2900'),
(44, 12, ' Casual Shoe', '<h1><i>Mochi</i></h1><br>\r\nMochi Casual Shoe For Men (Brown)\r\n<P>Simple Shoe <br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568560489casual3.jpg', '2679'),
(45, 12, 'Sneakers Shoe', '<h1><i>Mochi</i></h1><br>\r\nMochi Sneakers Shoe For Men (blue)\r\n<br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568560577Sneakers4.jpg', '2799'),
(46, 12, 'Sports Shoe', '<h1><i>Mochi</i></h1><br>\r\nMochi Sports Shoe For Men (Black)<br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568560802sports4.jpg', '2699'),
(47, 13, 'Sneakers Shoe', '<h1><i>Liberty</i></h1><br>\r\nLiberty Sports Shoe For Men (Black)\r\n<P>First one arrival <br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568560936Sneakers.jpg', '2459'),
(48, 13, ' Casual Shoe', '<h1><i>Liberty</i></h1><br>\r\nLiberty Casual Shoe For Men (Black)\r\n<P>New arrival <br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568561093casual.jpg', '1949'),
(49, 13, 'Formal Shoe', '<h1><i>Liberty</i></h1><br>\r\nLiberty Formal Shoe For Men (Black)\r\n<br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568561210formal2.jpg', '2599'),
(50, 13, 'Sports Shoe', '<h1><i>Liberty</i></h1><br>\r\nLiberty Sports Shoe For Men (White)<br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568561295sports2.jpg', '2399'),
(51, 13, 'Sneakers Shoe', '<h1><i>Liberty</i></h1><br>\r\nLiberty Sneakers Shoe For Men (Red)\r\n<P>Fresh arrival <br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568561400Sneakers1.jpg', '2349'),
(52, 13, ' Casual Shoe', '<h1><i>Liberty</i></h1><br>\r\nLiberty Casual Shoe For Men  <br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568561468casual3.jpg', '2549'),
(53, 13, 'Formal Shoe', '<h1><i>Liberty</i></h1><br>\r\nLiberty Formal Shoe For Men (Brown)<p>Newly arrival <br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568561607formal1.jpg', '2303'),
(54, 13, 'Sports Shoe', '<h1><i>Liberty</i></h1><br>\r\nLiberty Sports Shoe For Men <br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568561736sports.jpg', '2499'),
(55, 13, 'Sneakers Shoe', '<h1><i>Liberty</i></h1><br>\r\nLiberty Sneakers Shoe For Men (White)\r\n<P>Fresh arrival <br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568561831Sneakers3.jpg', '2699'),
(56, 13, ' Casual Shoe', '<h1><i>Liberty</i></h1><br>\r\nLiberty Casual Shoe For Men  <br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568561909casual2.jpg', '2399'),
(57, 13, 'Formal Shoe', '<h1><i>Liberty</i></h1><br>\r\nLiberty Formal Shoe For Men (Black)<p>Party Wear Shoe <br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568562000formal3.jpg', '2569'),
(58, 13, 'Sports Shoe', '<h1><i>Liberty</i></h1><br>\r\nLiberty Sports Shoe For Men<p>Running Shoe <br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568562094sports3.jpg', '2449'),
(59, 14, 'Sports Shoe', '<h1><i>Khadim</i></h1><br>\r\nKhadim Sports Shoe For Men (Blue)<p><br><h3><b>Services:</b><br><p>1) 15 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  45 day <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568562544sports.jpg', '1999'),
(60, 14, 'Formal Shoe', '<h1><i>Khadim</i></h1><br>\r\nKhadim Formal Shoe For Men (Black)<p>Party Wear Shoe <br><h3><b>Services:</b><br><p>1) 15 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  45 Days <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568617521formal4.jpg', '2299'),
(61, 14, ' Casual Shoe', '<h1><i>Khadim</i></h1><br>\r\nKhadim Casual Shoe For Men (Cream) <br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568562766casual.jpg', '2229'),
(62, 14, 'Sneakers Shoe', '<h1><i>Khadim</i></h1><br>\r\nKhadim Sneakers Shoe For Men (White)\r\n<P>Fresh arrival <br><h3><b>Services:</b><br><p>1) 15 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b> 45 Day <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568617645Sneakers4.jpg', '2899'),
(63, 14, 'Sports Shoe', '<h1><i>Khadim</i></h1><br>\r\nKhadim Sports Shoe For Men (White)<p><br><h3><b>Services:</b><br><p>1) 15 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  45 day <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568563069sports1.jpg', '2489'),
(64, 14, 'Formal Shoe', '<h1><i>Khadim</i></h1><br>\r\nKhadim Formal Shoe For Men (Black)<p> <br><h3><b>Services:</b><br><p>1) 15 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  45 Days <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568563179formal1.jpg', '2599'),
(65, 14, ' Casual Shoe', '<h1><i>Khadim</i></h1><br>\r\nKhadim Casual Shoe For Men <br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568563301casual2.jpg', '1999'),
(66, 14, 'Sneakers Shoe', '<h1><i>Khadim</i></h1><br>\r\nKhadim Sneakers Shoe For Men (Black)\r\n<P>Newly arrival <br><h3><b>Services:</b><br><p>1) 15 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b> 45 Day <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568563391Sneakers.jpg', '2199'),
(67, 14, 'Sports Shoe', '<h1><i>Khadim</i></h1><br>\r\nKhadim Sports Shoe For Men <p>Running Shoe<br><h3><b>Services:</b><br><p>1) 15 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  45 day <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568563562sports3.jpg', '2199'),
(68, 14, 'Formal Shoe', '<h1><i>Khadim</i></h1><br>\r\nKhadim Formal Shoe For Men (Tan)<p>Fresh Arrival <br><h3><b>Services:</b><br><p>1) 15 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  45 Days <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568564034formal.jpg', '2299'),
(69, 14, ' Casual Shoe', '<h1><i>Khadim</i></h1><br>\r\nKhadim Casual Shoe For Men <br><h3><b>Services:</b><br><p>1) 20 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b>  2 Month <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568564095casual3.jpg', '1699'),
(70, 14, 'Sneakers Shoe', '<h1><i>Khadim</i></h1><br>\r\nKhadim Sneakers Shoe For Men (Black)\r\n<P>New Fresh arrival <br><h3><b>Services:</b><br><p>1) 15 Day Return Policy<br>2) Cash on Delivery available\r\n</p><b>Warranty</b> 45 Day <br><br>Delivery: <p> Usually Delivered in 4-5 days</p>', '1568564158Sneakers1.jpg', '2199');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contect`
--
ALTER TABLE `contect`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`p_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  MODIFY `admin_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `b_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `contect`
--
ALTER TABLE `contect`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `p_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
