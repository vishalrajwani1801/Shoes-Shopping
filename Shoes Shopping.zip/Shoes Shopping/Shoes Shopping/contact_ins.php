<?php
	require_once('connection.php');
	
	
$c_fn = $_POST['c_fn'];
$c_ln = $_POST['c_ln'];
$c_email = $_POST['c_email'];
$c_pn = $_POST['c_pn'];
$c_message = $_POST['c_message'];
$ins = "INSERT INTO `contact` (`name`, `lname`, `email`, `mobile`, `comment`) VALUES ('$c_fn', '$c_ln', '$c_email', '$c_pn', '$c_message')";
mysqli_query($connection,$ins);

header('location:contact.php');

?>