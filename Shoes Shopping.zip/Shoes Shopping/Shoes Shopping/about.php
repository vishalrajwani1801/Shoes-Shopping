<?php
	require_once('connection.php');
	require_once('header.php');
?>


 <header class="section background-primary text-center">
            <h1 class="text-white margin-bottom-0 text-size-50 text-thin text-line-height-1">About Us</h1>
        </header>
	<div class="register">
	  <div class="container">
	  	<div class="about_box">
	  	  <div class="col-md-9 col_3">
	  		`<h2>Our History</h2>
	  		<p> </p>
	  		<p> </p>
	  	  </div>
	  	  <div class="col-md-3 col_4">
	  	   <img src="images/3.png" class="img-responsive" alt=""/>
	  	  </div>
		  <div class="clearfix"> </div>
		</div>
		<div class="about_box1">
	  	  <div class="col-md-9 col_3">
	  		
	  		</div>
	  	  <div class="col-md-3 col_4">
	  	
	  	  </div>
		  <div class="clearfix"> </div>
		</div>
		<p><h3>Who we are?</h3></p>
<font face="Arial" color="liam">A group of people who got together to create footwear, but got high on style somewhere in between, started watching fashion networks and created something that can be recognized only by someone out of this planet. That's how we started and that's how we are still going on.
We are India's one of its kind online personalized store with a group of stylists to recommend you the most stylish footwear as per your needs.
</h5><br>
<br>
	<p><h3>What we Do?</h3></p>
Well, to start with - Everything to make you feel Special! A stylist to discuss your fashion needs, a delivery guarantee, and no question asked return/exchange policy and a promise to ensure quality in all our products.
<br>
<br>

	<p><h3>How to Get it Going:</h3></P>
Welcome to the world of Shoe Shopping - a smart, quick and easy way to get yourself access to the latest fasion. All you need to do is access our online store. Once you tell us what you like, our team of stylists will take you to an exciting journey, showing you the variety we boast of and will help you choose the best. And believe us - online shopping at Shoe shopping is a lot of fun, not even a bit of it will disappoint you.</p>

 </p>
	  </div>
	</div>
	
	
<?php
	require_once('footer.php');
?>