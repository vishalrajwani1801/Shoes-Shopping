<?php
	require_once('connection.php');
?>

<!DOCTYPE HTML>
<html>
<head>
<title>Welcome To ShoeShopping</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Photo-Hub Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Quicksand:300,400,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
<script src="js/menu_jquery.js"></script>
</head>
<body>
	<div class="header">	
      <div class="container"> 
  	     <div class="logo">
			<h1><a href="index.php">Shoe Shopping</a></h1>
		 </div>
		 <div class="top_right">
		   <ul>
			<li class="active"><a href="index.php">Home</a></li>
			<li><a href="category.php">Category</a></li>
			<li><a href="about.php">About Us</a></li>
			<!-- <li><a href="accessories.php">Accessories</a></li> -->
			<li><a href="contact.php">Contact Us</a></li>
		   </ul>
	     </div>
		 <div class="clearfix"></div>
		</div>
	</div>